#!/usr/bin/env python



from back import MyClass

b = MyClass("Foo")

print b.getFoo()



