content-type:text/html\n\n
<HTML><BODY>
<FORM Method='GET' Action = '/home/team4/public_html/cgi-bin/finance.py'>
<INPUT type='text' Name='Stock Ticker' value='stockName'>
<INPUT type='submit' Value='submit'>
</FORM>
</BODY></HTML>
