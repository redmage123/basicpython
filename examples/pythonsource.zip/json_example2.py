#!/usr/bin/env python
import json


with open("presidents.txt")
d=[] 

d = json.load(f)


print d[0]["color"]
print d[0]["value"]



