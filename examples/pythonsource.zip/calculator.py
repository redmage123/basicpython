class Calculator(object):
    def __init__(self):
        pass

    def add(self,x,y):
        return(x+y)

    def sub(self,x,y):
        return (x-y)

    def mul(self,x,y):
        return(x*y)

    def div(self,x,y):
        return(x/y)
