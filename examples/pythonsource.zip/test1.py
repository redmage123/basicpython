#!/usr/bin/env python


import system

os.system('clear')

print "Hello World"
