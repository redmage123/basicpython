#!/usr/bin/env python

def test1():
    try:
        from vector import Vector
    except ImportError:
        print "Test1 failed!"
    else:
        print "Test1 succeeded!"


def test2():
     from vector import Vector
     v = Vector(1,1)
     print type(v)
     try:
         assert (v != None)
     except AssertionError:
         print "Test2 failed!"
     else:
        print "Test2 succeeded!"

def test3():
    from vector import Vector
    v1 = Vector(1,1)
    v2 = Vector(2,2)
    try:
        v3 = v1 + v2
        assert (v3 != None)
    except AssertionError:
         print "Test3 failed!"
    except TypeError:
        print "Test 3 failed.  No such attribute"
    else:
         print "test 3 succeeded!"


test1()
test2()
test3()
