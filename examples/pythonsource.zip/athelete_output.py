#!/usr/bin/env python



f = open("athelete_data_subset",'r+')
f.readline()

for data in f:
    strippeddata = data.strip()
    athelete_data_list = strippeddata.split(",")
    if int(athelete_data_list[1]) > 24 and athelete_data_list[2] == "United States":
        print strippeddata

f.close()
