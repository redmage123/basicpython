#!/usr/bin/env python 

hello = "Hello World"
print hello
