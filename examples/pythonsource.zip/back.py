#!/usr/bin/env python


class MyClass(object):
    def __init__(self,foo):
        self.foo = foo
    def getFoo(self):
        return (self.foo)



