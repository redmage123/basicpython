#!/usr/bin/env python


Class Vector(object):
    def __init__(self,x,y):
        pass
