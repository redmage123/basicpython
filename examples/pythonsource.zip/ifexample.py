#!/usr/bin/env python

str3 = "hello world"

if str3 != "hello world":
    print "No hello\'s here!"
else: 
    print "Hello\'s all around"

print "Outside the if, hello to all"
