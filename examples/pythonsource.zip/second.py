#!/usr/bin/env python



inputvar=raw_input("Please enter something in: ")
print inputvar
