#!/usr/bin/env python



class FirstClass():

    classcounter = 0
    __myname = None
    def __init__(self,name):
        self.__myname = name
        FirstClass.classcounter +=1
    def  getName(self):
        return self.__myname



c1 =  FirstClass("Braun Brelin")
c1.__myname = "bla"
print c1.__myname
